%Ghanem, A. S., Venkatesh, S. & West, G. (2010). Multi-class pattern classification in imbalanced data. International Conference on Pattern Recognition. IEEE Computer Society, 2010 (PP. 2881-2884).
% To handle the imbalanced class problem in relational domains, 
% PRMs-IM has been proposed as an ensemble of PRM models, 
% in which each model is trained on a balanced subset of the training data.
% Each data subset is constructed from the original imbalanced dataset to include
% all the samples from the minority class and an equal number
% of samples selected randomly from the majority class.
% A PRM model is then learned from each subset.
% Once the learning phase is complete, the PRM models are combined
% using the weighting voting strategy, where each model may
% have a different weight for classifying new instances.
function pre = multiIMcart(traindata,trainlabel,testdata)
% find minority class
table = tabulate(trainlabel);
idxt=find(table(:,2)>0);
table=table(idxt,:);

if table(1,2)<table(2,2)
    idxp = (trainlabel()==table(1,1));
    R=ceil(table(2,2)/table(1,2));
else
     idxp = (trainlabel()==table(2,1));
    R=ceil(table(1,2)/table(2,2));
end
%idxp = (trainlabel0()==1);
P = [traindata(idxp,:),trainlabel(idxp,:)];%P is the samples of minority class
N = [traindata(~idxp,:),trainlabel(~idxp,:)];%N is the samples of majority class
numberP=length(trainlabel(idxp,:));
% data{i} is constructed from the original imbalanced dataset to include
% all the samples from the minority class and an equal number
% of samples selected randomly from the majority class.
for i=1:R-1
    data{i}=[P;N(numberP*(i-1)+1:numberP*i,:)];%
end
data{R}=[P;N(numberP*(i-1)+1:end,:)];
for i=1:R
    train=data{R};
    test=[];
    for j=1:R
        if i~=j
            test=[test;data{R}];
        end
    end
    ft{i} = classregtree(train(:,1:end-1),train(:,end),'method','classification');% A PRM model is then learned from each subset.
    if R==1
        prec=eval(ft{i},train(:,1:end-1));
        prec=cellfun(@str2num, prec);
        ACc=train(:,end)-prec;
        ANc=find(ACc==0);
        acc(i)=size(ANc,1)/length(prec);
    else
        prec=eval(ft{i},test(:,1:end-1));
        prec=cellfun(@str2num, prec);
        ACc=test(:,end)-prec;
        ANc=find(ACc==0);
        acc(i)=size(ANc,1)/length(prec);
    end
    
end

% Once the learning phase is complete, the PRM models are combined
% using the weighting voting strategy, where each model may
% have a different weight for classifying new instances.
weight=acc/sum(acc);
results=zeros(size(testdata,1),2);    
for i=1:R
    prec=eval(ft{i},testdata);
    prec=cellfun(@str2num, prec);
    for j=1:length(prec)
        if prec(j)==table(1,1)
            results(j,1)=results(j,1)+weight(i);
        else 
            results(j,2)=results(j,2)+weight(i);
        end
    end
end
for j=1:size(testdata,1)
    if results(j,1)>results(j,2)
        pre(j)=table(1,1);
        
    else
        pre(j)=table(2,1);
    end
end


