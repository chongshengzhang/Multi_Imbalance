%Ghanem, A. S., Venkatesh, S. & West, G. (2010). Multi-class pattern classification in imbalanced data. International Conference on Pattern Recognition. IEEE Computer Society, 2010 (PP. 2881-2884).
%Multi-IM+OAHO

%OAHO first sorts in descending order the class by the number of samples.
%Let the sorted class being {C1,C2,...,Ck},with C1 having the largest number of samples.
%Starting from C1 until Ck-1, OAHO sequentially makes the current class as ��positive class��
%and all the rest classes with lower ranks as ��negative classes��,and then trains a binary classifier. 
%Therefore, there will be k-1 binary classifiers in total. 
%When predicting a new sample, the first classifier is used to predict it,
%if the prediction result is C1 then output C1 as the final result; 
%otherwise, it switches to the second classifier to make the prediction, 
%and so on, until the final prediction result is obtained.

function [time1,time2,pre0] = classOAHO(train,testdata)
tic;
TABLE = tabulate(train(:,end));
idxt=find(TABLE(:,2)>0);
TABLE=TABLE(idxt,:);
[b,index]=sort(TABLE(:,2)');
% maxlabel1=TABLE(index(end),1);
% maxlabel2=TABLE(index(end-1),1);
labels = TABLE(:,1);
numberc=length(labels);
flagc=1;
for i=numberc:-1:2
    maxlabel=TABLE(index(i),1);
    idi=(train(:,end)==maxlabel);
    Dij=train(idi,:);
    maxlabel2=TABLE(index(i-1),1);
    for j=i-1:-1:1
        maxlabeln=TABLE(index(j),1);

        idj=(train(:,end)== maxlabeln);
        Didj=train(idj,:);
        Didj(:,end)=maxlabel2;
        Dij=[Dij;Didj];       
    end
    
%     Cbest= bestClassifier(Dij,kfold);%%%%%%%%%%%%%%%%%%%%%%%%%class
    pre(:,flagc) = multiIMcart(Dij(:,1:end-1),Dij(:,end),testdata);

%     D{flagc}=Dij;
%     C{flagc}=Cbest;
    flagc=flagc+1;
end
time1=toc;

tic;
numbertest=size(testdata,1);

for i=1:numbertest
    for j=1:size(pre,2)
            pre0(i) = pre(i,j);%%%%%%%%%%%%%%%%%%pre
            if pre0(i)==TABLE(index(numberc-j+1),1)
                break;
            end
    end
end
time2=toc;

