%Ghanem, A. S., Venkatesh, S. & West, G. (2010). Multi-class pattern classification in imbalanced data. International Conference on Pattern Recognition. IEEE Computer Society, 2010 (PP. 2881-2884).
%Multi-IM+OVO
% In the OVO approach, an independent binary classifier is
% built for each pair of classes. Thus, a classifier multiIMcart is trained
% using the samples of classes i and j, and hence this classifier
% is trained to discriminate between these two classes only.
% The simplest approach to combine the results of the OAO
% binary classifiers is majority voting, in which the test sample
% is assigned to the class with the highest number of votes.
function [time1,time2,pre0] = classOAO(train,testdata)
tic;
labels = unique (train(:,end));
numberc=length(labels);
flagc=1;
for i=1:numberc-1
    for j=i+1:numberc
        idi=(train(:,end)==labels(i));
        idj=(train(:,end)==labels(j));
        Dij=[train(idi,:);train(idj,:)];
%         Cbest= bestClassifier(Dij,kfold);%%%%%%%%%%%%%%%%%%%%%%%%%class
        pre{flagc} = multiIMcart(Dij(:,1:end-1),Dij(:,end),testdata);
%        D{flagc}=Dij;
%         C{flagc}=Cbest;
        flagc=flagc+1;
    end
end
time1=toc;

tic;
numbertest=size(testdata,1);
numberC=length(pre);
allpre=zeros(numbertest,numberC);
for t=1:length(pre)
    allpre(:,t)=pre{t};%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%pre
end
pre0=mode(allpre,2);
time2=toc;

