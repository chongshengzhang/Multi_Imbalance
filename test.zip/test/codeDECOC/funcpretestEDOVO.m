function prelabel = funcpretestEDOVO(testdata,code,ft,W,D)
numbertest=size(testdata,1);
numberclass=size(code,1);
testlabel=testdata(1:numbertest,end);

testlabel(:)=0;
testlabel(2)=1;
fX = funcPreEDOVO(testdata,testlabel,ft,D);
[a,b]=size(fX);
for i=1:a
    for j=1:b
        if fX(i,j)==0
            fX(i,j)=-1;
        end
    end
end
for i=1:numbertest
    ftx=fX(i,:);
    for r=1:numberclass
        for t=1:length(ftx)
            btr(t)=(1-ftx(t)*code(r,t))/2;
        end
        br=btr';
        yall(r)=W*br;
    end

    [minval,minindex]=min(yall);
    prelabel(i)=minindex;
end




