function [pre,C] = EDOAO(train,testdata,testlabel,kfold)
labels = unique (train(:,end));
numberc=length(labels);
flagc=1;
for i=1:numberc
    for j=i+1:numberc
        idi=(train(:,end)==labels(i));
        idj=(train(:,end)==labels(j));
        Dij=[train(idi,:);train(idj,:)];
        
        
        clabels = unique (Dij(:,end));
        ctrainlabel=Dij(:,end);
        for ci=1:length(ctrainlabel)
            if ctrainlabel(ci)==clabels(1)
                ctrainlabel(ci)=0;
            else
                ctrainlabel(ci)=1;
            end
        end
        train1=[Dij(:,1:end-1),ctrainlabel];
        Dij=train1;


        [Cbest,bestk] = bestClassifier(Dij,kfold);
        D{flagc}=Dij;
        C{flagc,1}=Cbest;
        C{flagc,2}=bestk;
        L{flagc}=clabels;
        flagc=flagc+1;
    end
end
 pre = funcPre(testdata,testlabel,C,D,L); 
 %disp(Cbest);