function [time1,time2,prelabel] = imECOCDOVO(traindata,trainlabel,testdata,type,withw)
tic;
[code,ft,labels,D] = funclassifierEDOVO(traindata,trainlabel,type);
W = funcwEDOVO(traindata,trainlabel,code,ft,labels,D);
if withw==0
    W(1:length(ft))=1;
end
time1=toc;
tic;
pre = funcpretestEDOVO(testdata,code,ft,W,D);
for i=1:length(pre)
    prelabel(i)=labels(pre(i));
end


 prelabel= prelabel';
 time2=toc;