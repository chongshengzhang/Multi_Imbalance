% E. Ramentol, S. Vluymans, N. Verbiest, et al. , IFROWANN: Imbalanced Fuzzy-Rough Ordered Weighted Average Nearest Neighbor Classification, IEEE Transactions on Fuzzy Systems 23 (5) (2015) 1622-1637.

function prelabel=testfuzzyecoc(traindata,trainlabel,testdata,testlabel,weightStrategy,gamma)

labels = unique (trainlabel);
numberc=length(labels);
code = funECOC(numberc);
for i=1:numberc
    idi=(trainlabel==labels(i));
    train{i}=traindata(idi,:);
    numbern(i)=length(trainlabel(idi));
end
numberl=size(code,2);
for t=1:numberl
    Dt=[];
    Dtlabel=[];
    flagDt=0;
    numberAp=0;
    numberAn=0;
    numberNp=0;
    numberNn=0;
    for i=1:numberc
        if code(i,t)==1
            Dt=[Dt;train{i}];
            Dtlabel(flagDt+1:flagDt+numbern(i))=1;
            flagDt=flagDt+numbern(i);
            numberAp=numberAp+1;
            numberNp=numberNp+numbern(i);
        elseif code(i,t)==-1
            Dt=[Dt;train{i}];
            Dtlabel(flagDt+1:flagDt+numbern(i))=0;
            flagDt=flagDt+numbern(i);
            numberAn=numberAn+1;
            numberNn=numberNn+numbern(i);
        end
    end
    
    %ft{t} = fit_Hellinger_tree(Dt,Dtlabel');
    fX(:,t)=fuzzyImb(Dt,Dtlabel',testdata,testlabel,weightStrategy,gamma);
end

numbertest=size(testdata,1);
numberclass=size(code,1);
% for t=1:length(ft)
%     fX(:,t)=predict_Hellinger_tree(ft{t},testdata);
% end
for i=1:numbertest
    ftx=fX(i,:);
    for t=1:length(ftx)
        if ftx(t)==0
            ftx(t)=-1;
        end
    end
   
    for r=1:numberclass
        for t=1:length(ftx)
            btr(t)=(1-ftx(t)*code(r,t))/2;
        end
        yall(r)=sum(btr);
    end

    [minval,minindex]=min(yall);
    prelabel(i)=labels(minindex);
end

prelabel=prelabel';
% correct = (prelabel == testlabel);
% correct = sum(correct) / length(correct);

