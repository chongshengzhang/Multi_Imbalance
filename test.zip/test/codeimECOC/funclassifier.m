%Liu, X. Y., Li, Q. Q. & Zhou Z H. (2013). Learning imbalanced multi-class data with optimal dichotomy weights. IEEE 13th International Conference on Data Mining (IEEE ICDM), 2013 (PP.  478-487).
% the pseudocose of imECOC in the file "The pseudocode of imECOC in papers.docx"
% step 1-10
function [code,ft,labels] = funclassifier(traindata,trainlabel,type)
labels = unique (trainlabel);
numberc=length(labels);
code = funECOCim(numberc,type);%step 1 generate code matrix
for i=1:numberc
    idi=(trainlabel==labels(i));
    train{i}=traindata(idi,:);
    numbern(i)=length(trainlabel(idi));
end
numberl=size(code,2);
for t=1:numberl%step 2-10
    Dt=[];%step 3 Dt=?
    Dtlabel=[];
    flagDt=0;
    numberAp=0;
    numberAn=0;
    numberNp=0;
    numberNn=0;
    for i=1:numberc%step 4-8 Dt=[Dt;train{i}]
        if code(i,t)==1
            Dt=[Dt;train{i}];
            Dtlabel(flagDt+1:flagDt+numbern(i))=1;
            flagDt=flagDt+numbern(i);
            numberAp=numberAp+1;
            numberNp=numberNp+numbern(i);
        elseif code(i,t)==-1
            Dt=[Dt;train{i}];
            Dtlabel(flagDt+1:flagDt+numbern(i))=-1;
            flagDt=flagDt+numbern(i);
            numberAn=numberAn+1;
            numberNn=numberNn+numbern(i);
        end
    end
    ct=[];
    flagct=0;
    for i=1:numberc%step 9 calculate the example weights ct for the t-th dichotomy according to Eq. 2.
        if code(i,t)==1
            cti=max(numberNp,numberNn)/(numberAp*numbern(i));
            ct(flagct+1:flagct+numbern(i))=cti;
            flagct=flagct+numbern(i);
        elseif code(i,t)==-1
            cti=max(numberNp,numberNn)/(numberAn*numbern(i));
            ct(flagct+1:flagct+numbern(i))=cti;
            flagct=flagct+numbern(i);
        end 
    end
    ft{t} = classregtree(Dt,Dtlabel,'weights',ct,'method','classification');%step 10 learn a classifier using the weighted examples
end
%yfit=eval(ft(t),X)

    
            