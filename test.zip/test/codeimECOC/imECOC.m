%Liu, X. Y., Li, Q. Q. & Zhou Z H. (2013). Learning imbalanced multi-class data with optimal dichotomy weights. IEEE 13th International Conference on Data Mining (IEEE ICDM), 2013 (PP.  478-487).

function [time1,time2,prelabel] = imECOC(traindata,trainlabel,testdata,type,withw)
tic;
[code,ft,labels] = funclassifier(traindata,trainlabel,type);%step 1-10
W = funcw(traindata,trainlabel,code,ft,labels);%step 11-12
if withw==0
    W(1:length(ft))=1;
end
time1=toc;
tic;
pre = funcpre(testdata,code,ft,W);%step 14-15
for i=1:length(pre)
    prelabel(i)=labels(pre(i));
end


 prelabel= prelabel';
 time2=toc;