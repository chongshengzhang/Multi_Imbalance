%Kang, S., Cho, S. & Kang P. (2015) Constructing a multi-class classifier using one-against-one approach with different binary classifiers. Neurocomputing, 2015, 149, 677-682.


function [time1,time2,pre,C] = DOAO(train,testdata,testlabel,kfold)
tic;
labels = unique (train(:,end));
numberc=length(labels);
flagc=1;
%step 3 for each class pair (i,j) do
for i=1:numberc
    for j=i+1:numberc
        idi=(train(:,end)==labels(i));
        idj=(train(:,end)==labels(j));
        Dij=[train(idi,:);train(idj,:)];% step 4 Dij:a set of data points whose class labels are i or j
        
        
        clabels = unique (Dij(:,end));
        ctrainlabel=Dij(:,end);
        for ci=1:length(ctrainlabel)%transform class labels  (i ,j) to (0 , 1)
            if ctrainlabel(ci)==clabels(1)
                ctrainlabel(ci)=0;
            else
                ctrainlabel(ci)=1;
            end
        end
        train1=[Dij(:,1:end-1),ctrainlabel];
        Dij=train1;


        [Cbest,bestk] = bestClassifier(Dij,kfold);%step 4-7 find Cbest  that corresponds to the minimum validation error
        D{flagc}=Dij;
        C{flagc,1}=Cbest;
        C{flagc,2}=bestk;
        L{flagc}=clabels;
        flagc=flagc+1;
    end
end
time1=toc;
tic;
 pre = funcPre(testdata,testlabel,C,D,L); %test phase
 time2=toc;
 %disp(Cbest);