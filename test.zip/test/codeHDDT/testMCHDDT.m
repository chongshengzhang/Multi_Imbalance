function [time1,time2,predictions]=testMCHDDT(traindata,trainlabel,testdata,testlabel)
tic;
    trainingLabels = trainlabel ;
    trainingFeatures = traindata;
    testLabels = testlabel;
    testFeatures = testdata;
    
   

    model = fit_Hellinger_treeMC(trainingFeatures,trainingLabels);%
time1=toc;
tic;
    predictions = predict_Hellinger_tree(model,testFeatures);
time2=toc;
    
    
  